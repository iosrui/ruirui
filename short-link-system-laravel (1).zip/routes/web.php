<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ShortLinkController;

// 短链跳转路由
Route::get('/{shortPath}', [ShortLinkController::class, 'redirect']);

// 管理员后台路由
Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function () {
    Route::get('/', [AdminController::class, 'index']);
    Route::get('users', [AdminController::class, 'manageUsers']);
    Route::post('users', [AdminController::class, 'addUser']);
    Route::get('users/{user}/edit', [AdminController::class, 'editUser']);
    Route::put('users/{user}', [AdminController::class, 'updateUser']);
    Route::delete('users/{user}', [AdminController::class, 'deleteUser']);
    Route::post('users/{user}/disable', [AdminController::class, 'disableUser']);
    Route::get('short-links', [AdminController::class, 'manageShortLinks']);
    Route::post('short-links', [AdminController::class, 'addShortLink']);
    Route::get('short-links/{shortLink}/edit', [AdminController::class, 'editShortLink']);
    Route::put('short-links/{shortLink}', [AdminController::class, 'updateShortLink']);
    Route::delete('short-links/{shortLink}', [AdminController::class, 'deleteShortLink']);
    Route::get('domain-pools', [AdminController::class, 'manageDomainPools']);
    Route::post('domain-pools', [AdminController::class, 'addDomainPool']);
    Route::get('domain-pools/{domainPool}/edit', [AdminController::class, 'editDomainPool']);
    Route::put('domain-pools/{domainPool}', [AdminController::class, 'updateDomainPool']);
    Route::delete('domain-pools/{domainPool}', [AdminController::class, 'deleteDomainPool']);
    Route::get('ip-blacklist', [AdminController::class, 'manageIpBlacklist']);
    Route::post('ip-blacklist', [AdminController::class, 'addIpToBlacklist']);
    Route::delete('ip-blacklist/{ipBlacklist}', [AdminController::class, 'removeIpFromBlacklist']);
    Route::get('access-logs', [AdminController::class, 'manageAccessLogs']);
    Route::get('card-codes', [AdminController::class, 'manageCardCodes']);
    Route::post('card-codes', [AdminController::class, 'addCardCode']);
    Route::delete('card-codes/{cardCode}', [AdminController::class, 'deleteCardCode']);
    Route::post('search', [AdminController::class, 'search']);
});

// 用户后台路由
Route::group(['prefix' => 'user', 'middleware' => 'auth'], function () {
    Route::get('/', [UserController::class, 'index']);
    Route::get('short-links', [UserController::class, 'manageShortLinks']);
    Route::post('short-links', [UserController::class, 'addShortLink']);
    Route::get('short-links/{shortLink}/edit', [UserController::class, 'editShortLink']);
    Route::put('short-links/{shortLink}', [UserController::class, 'updateShortLink']);
    Route::delete('short-links/{shortLink}', [UserController::class, 'deleteShortLink']);
    Route::get('domain-pools', [UserController::class, 'manageDomainPools']);
    Route::post('domain-pools', [UserController::class, 'addDomainPool']);
    Route::get('domain-pools/{domainPool}/edit', [UserController::class, 'editDomainPool']);
    Route::put('domain-pools/{domainPool}', [UserController::class, 'updateDomainPool']);
    Route::delete('domain-pools/{domainPool}', [UserController::class, 'deleteDomainPool']);
    Route::get('ip-blacklist', [UserController::class, 'manageIpBlacklist']);
    Route::post('ip-blacklist', [UserController::class, 'addIpToBlacklist']);
    Route::delete('ip-blacklist/{ipBlacklist}', [UserController::class, 'removeIpFromBlacklist']);
    Route::get('access-logs', [UserController::class, 'manageAccessLogs']);
    Route::post('activate-card', [UserController::class, 'activateCard']);
    Route::post('update-profile', [UserController::class, 'updateProfile']);
});

// 认证路由
Route::get('login', [UserController::class, 'showLoginForm'])->name('login');
Route::post('login', [UserController::class, 'login']);
Route::post('logout', [UserController::class, 'logout'])->name('logout');
Route::get('register', [UserController::class, 'showRegistrationForm']);
Route::post('register', [UserController::class, 'register']);
    </douba