<?php

namespace App\Http\Controllers;

use App\Models\ShortLink;
use App\Models\DomainPool;
use App\Models\AccessLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Redirect;

class ShortLinkController extends Controller
{
    public function redirect($shortPath)
    {
        $shortLink = ShortLink::where('short_path', $shortPath)->first();

        if (!$shortLink || $shortLink->is_disabled) {
            return response($shortLink->disable_page?? '短链已停用', 403);
        }

        if ($shortLink->jump_times > 0 && $shortLink->used_jump_times >= $shortLink->jump_times) {
            return response($shortLink->disable_page?? '跳转次数已达上限', 403);
        }

        if ($shortLink->expire_time && now() > $shortLink->expire_time) {
            return response($shortLink->disable_page?? '短链已过期', 403);
        }

        $ip = request()->ip();
        if (in_array($ip, $shortLink->block_ips?? [])) {
            return response($shortLink->block_ip_page?? '此 IP 禁止访问', 403);
        }

        $device = $this->detectDevice();
        if (in_array($device, $shortLink->block_devices?? [])) {
            return response($shortLink->block_device_page?? '此设备禁止访问', 403);
        }

        $region = $this->detectRegion($ip);
        if (in_array($region, $shortLink->block_regions?? [])) {
            return response($shortLink->block_region_page?? '此地区禁止访问', 403);
        }

        $ua = strtolower(request()->userAgent());
        if (strpos($ua,'micromessenger')!== false) {
            return response($shortLink->wechat_tip_page?? '请在浏览器中打开', 403);
        } elseif (strpos($ua, 'qq')!== false) {
            return response($shortLink->qq_tip_page?? '请在浏览器中打开', 403);
        }

        if ($shortLink->delay_time > 0) {
            return response($shortLink->delay_page?? '即将跳转，请稍候...', 200)
                ->header('Refresh', $shortLink->delay_time. ';url='. $this->getFinalUrl($shortLink));
        }

        $shortLink->increment('used_jump_times');
        AccessLog::create([
            'ip' => $ip,
            'device' => $device,
            'region' => $region,
            'short_link_id' => $shortLink->id,
            'is_success' => true
        ]);

        return Redirect::to($this->getFinalUrl($shortLink));
    }

    private function getFinalUrl($shortLink)
    {
        if ($shortLink->domainPool) {
            $parsedUrl = parse_url($shortLink->long_url);
            $newUrl = $parsedUrl['scheme']. '://'. $shortLink->domainPool->domain;
            if (isset($parsedUrl['path'])) {
                $newUrl.= $parsedUrl['path'];
            }
            if (isset($parsedUrl['query'])) {
                $newUrl.= '?'. $parsedUrl['query'];
            }
            return $newUrl;
        }
        return $shortLink->long_url;
    }

    private function detectDevice()
    {
        $ua = strtolower(request()->userAgent());
        if (strpos($ua, 'iphone')!== false || strpos($ua, 'ipad')!== false || strpos($ua, 'ipod')!== false) {
            return '苹果';
        } elseif (strpos($ua, 'android')!== false) {
            return '安卓';
        } elseif (strpos($ua, 'macintosh')!== false) {
            return '苹果电脑';
        } elseif (strpos($ua, 'windows')!== false) {
            return '微软电脑';
        }
        return '未知设备';
    }

    private function detectRegion($ip)
    {
        // 这里可以使用第三方服务获取地区信息，示例中简单返回未知地区
        return '未知地区';
    }
}
    