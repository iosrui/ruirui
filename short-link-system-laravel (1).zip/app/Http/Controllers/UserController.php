<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ShortLink;
use App\Models\DomainPool;
use App\Models\IpBlacklist;
use App\Models\AccessLog;
use App\Models\CardCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        return view('user.index');
    }

    public function showLoginForm()
    {
        return view('user.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended('/user');
        }

        return back()->withErrors([
            'username' => '用户名或密码错误'
        ])->onlyInput('username');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }

    public function showRegistrationForm()
    {
        return view('user.register');
    }

    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'username' => 'required|unique:users',
            'password' => 'required|min:6',
            'email' => 'nullable|email',
            'phone' => 'nullable|string'
        ]);

        $validatedData['password'] = Hash::make($validatedData['password']);
        User::create($validatedData);
        return redirect()->route('login')->with('success', '注册成功，请登录');
    }

    public function manageShortLinks()
    {
        $shortLinks = ShortLink::where('user_id', Auth::id())->get();
        return view('user.short_links', compact('shortLinks'));
    }

    public function addShortLink(Request $request)
    {
        $validatedData = $request->validate([
            'short_path' => 'required|unique:short_links',
            'long_url' => 'required|url',
            'domain_pool_id' => 'nullable|exists:domain_pools,id',
            'is_disabled' => 'boolean',
            'disable_page' => 'nullable|string',
            'qq_tip_page' => 'nullable|string',
            'wechat_tip_page' => 'nullable|string',
            'delay_time' => 'nullable|integer',
            'delay_page' => 'nullable|string',
            'block_regions' => 'nullable|json',
            'block_devices' => 'nullable|json',
            'block_ips' => 'nullable|json',
            'jump_times' => 'nullable|integer',
            'expire_time' => 'nullable|date'
        ]);

        $validatedData['user_id'] = Auth::id();
        ShortLink::create($validatedData);
        return redirect()->back()->with('success', '短链添加成功');
    }

    public function editShortLink(ShortLink $shortLink)
    {
        if ($shortLink->user_id!== Auth::id()) {
            return abort(403);
        }
        return view('user.edit_short_link', compact('shortLink'));
    }

    public function updateShortLink(Request $request, ShortLink $shortLink)
    {
        if ($shortLink->user_id!== Auth::id()) {
            return abort(403);
        }

        $validatedData = $request->validate([
            'short_path' => 'required|unique:short_links,short_path,'.$shortLink->id,
            'long_url' => 'required|url',
            'domain_pool_id' => 'nullable|exists:domain_pools,id',
            'is_disabled' => 'boolean',
            'disable_page' => 'nullable|string',
            'qq_tip_page' => 'nullable|string',
            'wechat_tip_page' => 'nullable|string',
            'delay_time' => 'nullable|integer',
            'delay_page' => 'nullable|string',
            'block_regions' => 'nullable|json',
            'block_devices' => 'nullable|json',
            'block_ips' => 'nullable|json',
            'jump_times' => 'nullable|integer',
            'expire_time' => 'nullable|date'
        ]);

        $shortLink->update($validatedData);
        return redirect()->back()->with('success', '短链信息更新成功');
    }

    public function deleteShortLink(ShortLink $shortLink)
    {
        if ($shortLink->user_id!== Auth::id()) {
            return abort(403);
        }
        $shortLink->delete();
        return redirect()->back()->with('success', '短链删除成功');
    }

    public function manageDomainPools()
    {
        $domainPools = DomainPool::where('user_id', Auth::id())->get();
        return view('user.domain_pools', compact('domainPools'));
    }

    public function addDomainPool(Request $request)
    {
        $validatedData = $request->validate([
            'domain' => 'required|unique:domain_pools',
            'type' => 'required|string',
            'is_disabled' => 'boolean'
        ]);

        $validatedData['user_id'] = Auth::id();
        DomainPool::create($validatedData);
        return redirect()->back()->with('success', '域名池添加成功');
    }

    public function editDomainPool(DomainPool $domainPool)
    {
        if ($domainPool->user_id!== Auth::id()) {
            return abort(403);
        }
        return view('user.edit_domain_pool', compact('domainPool'));
    }

    public function updateDomainPool(Request $request, DomainPool $domainPool)
    {
        if ($domainPool->user_id!== Auth::id()) {
            return abort(403);
        }

        $validatedData = $request->validate([
            'domain' => 'required|unique:domain_pools,domain,'.$domainPool->id,
            'type' => 'required|string',
            'is_disabled' => 'boolean'
        ]);

        $domainPool->update($validatedData);
        return redirect()->back()->with('success', '域名池信息更新成功');
    }

    public function deleteDomainPool(DomainPool $domainPool)
    {
        if ($domainPool->user_id!== Auth::id()) {
            return abort(403);
        }
        $domainPool->delete();
        return redirect()->back()->with('success', '域名池删除成功');
    }

    public function manageIpBlacklist()
    {
        $ipBlacklist = IpBlacklist::all();
        return view('user.ip_blacklist', compact('ipBlacklist'));
    }

    public function addIpToBlacklist(Request $request)
    {
        $validatedData = $request->validate([
            'ip' => 'required|ip'
        ]);

        IpBlacklist::create($validatedData);
        return redirect()->back()->with('success', 'IP 已加入黑名单');
    }

    public function removeIpFromBlacklist(IpBlacklist $ipBlacklist)
    {
        $ipBlacklist->delete();
        return redirect()->back()->with('success', 'IP 已从黑名单移除');
    }

    public function manageAccessLogs()
    {
        $accessLogs = AccessLog::whereHas('shortLink', function ($query) {
            $query->where('user_id', Auth::id());
        })->get();
        return view('user.access_logs', compact('accessLogs'));
    }

    public function activateCard(Request $request)
    {
        $validatedData = $request->validate([
            'code' => 'required|exists:card_codes,code'
        ]);

        $cardCode = CardCode::where('code', $validatedData['code'])->first();
        if ($cardCode->is_used) {
            return redirect()->back()->with('error', '卡密已被使用');
        }

        $user = Auth::user();
        $user->is_paid = true;
        switch ($cardCode->type) {
            case '月卡':
                $user->expire_date = now()->addMonth();
                break;
            case '季卡':
                $user->expire_date = now()->addMonths(3);
                break;
            case '年卡':
                $user->expire_date = now()->addYear();
                break;
        }
        $user->save();

        $cardCode->is_used = true;
        $cardCode->user_id = $user->id;
        $cardCode->save();

        return redirect()->back()->with('success', '卡密激活成功');
    }

    public function updateProfile(Request $request)
    {
        $user = Auth::user();
        $validatedData = $request->validate([
            'email' => 'nullable|email',
            'phone' => 'nullable|string',
            'username' => 'required|unique:users,username,'.$user->id,
            'password' => 'nullable|min:6'
        ]);

        if ($validatedData['password']) {
            $validatedData['password'] = Hash::make($validatedData['password']);
        } else {
            unset($validatedData['password']);
        }

        $user->update($validatedData);
        return redirect()->back()->with('success', '个人资料更新成功');
    }
}
    