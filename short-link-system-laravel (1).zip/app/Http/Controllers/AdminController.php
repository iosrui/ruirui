<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ShortLink;
use App\Models\DomainPool;
use App\Models\IpBlacklist;
use App\Models\AccessLog;
use App\Models\CardCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }

    public function search(Request $request)
    {
        $query = $request->input('query');
        $users = User::where('username', 'like', "%$query%")->get();
        $shortLinks = ShortLink::where('short_path', 'like', "%$query%")->get();
        return view('admin.search', compact('users', 'shortLinks'));
    }

    public function manageUsers()
    {
        $users = User::all();
        return view('admin.users', compact('users'));
    }

    public function addUser(Request $request)
    {
        $validatedData = $request->validate([
            'username' => 'required|unique:users',
            'password' => 'required|min:6',
            'email' => 'nullable|email',
            'phone' => 'nullable|string',
            'is_paid' => 'boolean',
            'expire_date' => 'nullable|date'
        ]);

        $validatedData['password'] = Hash::make($validatedData['password']);
        User::create($validatedData);
        return redirect()->back()->with('success', '用户添加成功');
    }

    public function editUser(User $user)
    {
        return view('admin.edit_user', compact('user'));
    }

    public function updateUser(Request $request, User $user)
    {
        $validatedData = $request->validate([
            'username' => 'required|unique:users,username,'.$user->id,
            'password' => 'nullable|min:6',
            'email' => 'nullable|email',
            'phone' => 'nullable|string',
            'is_paid' => 'boolean',
            'expire_date' => 'nullable|date'
        ]);

        if ($validatedData['password']) {
            $validatedData['password'] = Hash::make($validatedData['password']);
        } else {
            unset($validatedData['password']);
        }

        $user->update($validatedData);
        return redirect()->back()->with('success', '用户信息更新成功');
    }

    public function deleteUser(User $user)
    {
        $user->delete();
        return redirect()->back()->with('success', '用户删除成功');
    }

    public function disableUser(User $user)
    {
        $user->is_disabled = true;
        $user->save();
        return redirect()->back()->with('success', '用户已禁用');
    }

    public function manageShortLinks()
    {
        $shortLinks = ShortLink::all();
        return view('admin.short_links', compact('shortLinks'));
    }

    public function addShortLink(Request $request)
    {
        $validatedData = $request->validate([
            'short_path' => 'required|unique:short_links',
            'long_url' => 'required|url',
            'user_id' => 'required|exists:users,id',
            'domain_pool_id' => 'nullable|exists:domain_pools,id',
            'is_disabled' => 'boolean',
            'disable_page' => 'nullable|string',
            'qq_tip_page' => 'nullable|string',
            'wechat_tip_page' => 'nullable|string',
            'delay_time' => 'nullable|integer',
            'delay_page' => 'nullable|string',
            'block_regions' => 'nullable|json',
            'block_devices' => 'nullable|json',
            'block_ips' => 'nullable|json',
            'jump_times' => 'nullable|integer',
            'expire_time' => 'nullable|date'
        ]);

        ShortLink::create($validatedData);
        return redirect()->back()->with('success', '短链添加成功');
    }

    public function editShortLink(ShortLink $shortLink)
    {
        return view('admin.edit_short_link', compact('shortLink'));
    }

    public function updateShortLink(Request $request, ShortLink $shortLink)
    {
        $validatedData = $request->validate([
            'short_path' => 'required|unique:short_links,short_path,'.$shortLink->id,
            'long_url' => 'required|url',
            'user_id' => 'required|exists:users,id',
            'domain_pool_id' => 'nullable|exists:domain_pools,id',
            'is_disabled' => 'boolean',
            'disable_page' => 'nullable|string',
            'qq_tip_page' => 'nullable|string',
            'wechat_tip_page' => 'nullable|string',
            'delay_time' => 'nullable|integer',
            'delay_page' => 'nullable|string',
            'block_regions' => 'nullable|json',
            'block_devices' => 'nullable|json',
            'block_ips' => 'nullable|json',
            'jump_times' => 'nullable|integer',
            'expire_time' => 'nullable|date'
        ]);

        $shortLink->update($validatedData);
        return redirect()->back()->with('success', '短链信息更新成功');
    }

    public function deleteShortLink(ShortLink $shortLink)
    {
        $shortLink->delete();
        return redirect()->back()->with('success', '短链删除成功');
    }

    public function manageDomainPools()
    {
        $domainPools = DomainPool::all();
        return view('admin.domain_pools', compact('domainPools'));
    }

    public function addDomainPool(Request $request)
    {
        $validatedData = $request->validate([
            'domain' => 'required|unique:domain_pools',
            'type' => 'required|string',
            'user_id' => 'nullable|exists:users,id',
            'is_disabled' => 'boolean'
        ]);

        DomainPool::create($validatedData);
        return redirect()->back()->with('success', '域名池添加成功');
    }

    public function editDomainPool(DomainPool $domainPool)
    {
        return view('admin.edit_domain_pool', compact('domainPool'));
    }

    public function updateDomainPool(Request $request, DomainPool $domainPool)
    {
        $validatedData = $request->validate([
            'domain' => 'required|unique:domain_pools,domain,'.$domainPool->id,
            'type' => 'required|string',
            'user_id' => 'nullable|exists:users,id',
            'is_disabled' => 'boolean'
        ]);

        $domainPool->update($validatedData);
        return redirect()->back()->with('success', '域名池信息更新成功');
    }

    public function deleteDomainPool(DomainPool $domainPool)
    {
        $domainPool->delete();
        return redirect()->back()->with('success', '域名池删除成功');
    }

    public function manageIpBlacklist()
    {
        $ipBlacklist = IpBlacklist::all();
        return view('admin.ip_blacklist', compact('ipBlacklist'));
    }

    public function addIpToBlacklist(Request $request)
    {
        $validatedData = $request->validate([
            'ip' => 'required|ip'
        ]);

        IpBlacklist::create($validatedData);
        return redirect()->back()->with('success', 'IP 已加入黑名单');
    }

    public function removeIpFromBlacklist(IpBlacklist $ipBlacklist)
    {
        $ipBlacklist->delete();
        return redirect()->back()->with('success', 'IP 已从黑名单移除');
    }

    public function manageAccessLogs()
    {
        $accessLogs = AccessLog::all();
        return view('admin.access_logs', compact('accessLogs'));
    }

    public function manageCardCodes()
    {
        $cardCodes = CardCode::all();
        return view('admin.card_codes', compact('cardCodes'));
    }

    public function addCardCode(Request $request)
    {
        $validatedData = $request->validate([
            'code' => 'required|unique:card_codes',
            'type' => 'required|string'
        ]);

        CardCode::create($validatedData);
        return redirect()->back()->with('success', '卡密添加成功');
    }

    public function deleteCardCode(CardCode $cardCode)
    {
        $cardCode->delete();
        return redirect()->back()->with('success', '卡密删除成功');
    }
}
    