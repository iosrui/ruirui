<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DomainPool extends Model
{
    use HasFactory;

    protected $fillable = [
        'domain', 'type', 'user_id', 'is_disabled'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function shortLinks()
    {
        return $this->hasMany(ShortLink::class);
    }
}
    