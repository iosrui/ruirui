<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccessLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'ip', 'device', 'region', 'short_link_id', 'is_success'
    ];

    public function shortLink()
    {
        return $this->belongsTo(ShortLink::class);
    }
}
    