<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShortLink extends Model
{
    use HasFactory;

    protected $fillable = [
        'short_path', 'long_url', 'user_id', 'domain_pool_id', 'is_disabled', 'disable_page',
        'qq_tip_page', 'wechat_tip_page', 'delay_time', 'delay_page', 'block_regions',
        'block_devices', 'block_ips', 'jump_times', 'used_jump_times', 'expire_time'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function domainPool()
    {
        return $this->belongsTo(DomainPool::class);
    }

    public function accessLogs()
    {
        return $this->hasMany(AccessLog::class);
    }
}
    