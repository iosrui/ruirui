<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class InstallDatabase extends Command
{
    /**
     * 命令的签名
     *
     * @var string
     */
    protected $signature = 'db:install';

    /**
     * 命令的描述
     *
     * @var string
     */
    protected $description = 'Install the database for the short link system';

    /**
     * 执行命令
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Starting database installation...');

        try {
            Artisan::call('migrate:fresh');
            $this->info('Database migrations completed successfully.');

            // 可以在这里添加种子数据填充等操作

            $this->info('Database installation completed.');
        } catch (\Exception $e) {
            $this->error('Database installation failed: '. $e->getMessage());
        }

        return 0;
    }
}
    